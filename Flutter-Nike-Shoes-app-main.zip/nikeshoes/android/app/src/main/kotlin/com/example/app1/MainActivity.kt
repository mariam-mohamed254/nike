package com.example.shoesApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
